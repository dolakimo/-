import {
  authenticate,
  createId,
  createPortfolio,
  deletePortfolio,
  endSession,
  findPortfolio,
  initStore,
  isLoggedIn,
  loadState,
  registerUser,
  saveState,
} from './js/store.js';
import {
  formatFileSize,
  normalizeUrl,
  readFileAsDataUrl,
  readImage,
} from './js/utils.js';
import {
  clearFormError,
  renderHeader,
  setFormBusy,
  setFormError,
  showToast,
} from './js/components.js';
import {
  renderAbout,
  renderAuth,
  renderEditor,
  renderHome,
  renderProfile,
  renderPublic,
  renderSocial,
  renderUserEdit,
} from './js/views.js';

const app = document.querySelector('#app');

const PAGE_TITLES = {
  home: 'ProfileView',
  login: 'Вход — ProfileView',
  register: 'Регистрация — ProfileView',
  profile: 'Профиль — ProfileView',
  'user-edit': 'Редактирование профиля — ProfileView',
  editor: 'Создание портфолио — ProfileView',
  public: 'Портфолио — ProfileView',
  social: 'Соцсети — ProfileView',
  about: 'О нас — ProfileView',
};

const views = {
  home: renderHome,
  login: (state) => renderAuth('login', state),
  register: (state, options) => renderAuth('register', state, options.registrationCode),
  profile: renderProfile,
  'user-edit': renderUserEdit,
  editor: (state, options) => renderEditor(state, options.portfolioId),
  public: (state, options) => renderPublic(state, options.portfolioId),
  social: renderSocial,
  about: renderAbout,
};

const PROTECTED_PAGES = new Set(['profile', 'user-edit', 'editor']);
const AUTH_PAGES = new Set(['login', 'register']);
const IMAGE_FIELDS = new Set(['background', 'banner']);
const FILE_LABELS = {
  background: 'фон',
  audio: 'аудио',
  banner: 'баннер',
};

const MAX_IMAGE_FILE_SIZE = 8 * 1024 * 1024;
const MAX_AUDIO_FILE_SIZE = 1.5 * 1024 * 1024;
const GALLERY_IMAGE_MAX_SIDE = 1400;

let redirectTarget = null;
let registrationCode = '';

function createVerificationCode() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

function pageFromHash() {
  return window.location.hash.replace(/^#\/?/, '').split('?')[0] || 'home';
}

function portfolioIdFromHash() {
  const query = window.location.hash.split('?')[1] ?? '';
  return new URLSearchParams(query).get('id') ?? '';
}

function render() {
  let page = pageFromHash();
  const portfolioId = portfolioIdFromHash();

  if (!Object.hasOwn(views, page)) {
    page = 'home';
    history.replaceState(null, '', '#home');
  }

  if (PROTECTED_PAGES.has(page) && !isLoggedIn()) {
    redirectTarget = { page, portfolioId };
    page = 'login';
    history.replaceState(null, '', '#login');
  }

  registrationCode = page === 'register'
    ? registrationCode || createVerificationCode()
    : '';

  const state = loadState();
  const view = views[page];
  const options = { registrationCode, portfolioId };

  app.innerHTML = `${renderHeader(page)}${view(state, options)}`;
  document.title = PAGE_TITLES[page] ?? 'ProfileView';
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
}

function navigate(page, portfolioId = '') {
  const target = Object.hasOwn(views, page) ? page : 'home';

  // Remember where the user wanted to go after login/registration, but drop
  // the intent as soon as they visit a regular page.
  if (!AUTH_PAGES.has(target) && !PROTECTED_PAGES.has(target)) {
    redirectTarget = null;
  }

  const nextHash = portfolioId
    ? `${target}?id=${encodeURIComponent(portfolioId)}`
    : target;
  const currentHash = window.location.hash.replace(/^#/, '');

  if (currentHash === nextHash) {
    render();
    return;
  }

  window.location.hash = nextHash;
}

function storageMessage(error) {
  if (typeof error === 'string' && error) {
    return error;
  }

  return 'Не удалось сохранить данные. Попробуйте ещё раз.';
}

async function submitLogin(form) {
  const data = new FormData(form);
  const identifier = String(data.get('name') ?? '').trim();
  const password = String(data.get('password') ?? '');

  const result = await authenticate(identifier, password);
  if (!result.ok) {
    setFormError(form, result.error);
    return;
  }

  const target = redirectTarget ?? { page: 'profile', portfolioId: '' };
  redirectTarget = null;
  showToast('С возвращением!');
  navigate(target.page, target.portfolioId);
}

async function submitRegistration(form) {
  const data = new FormData(form);
  const name = String(data.get('name') ?? '').trim();
  const password = String(data.get('password') ?? '');
  const description = String(data.get('description') ?? '').trim();
  const email = String(data.get('email') ?? '').trim();
  const code = String(data.get('code') ?? '').trim();

  if (code !== registrationCode) {
    setFormError(form, 'Неверный код подтверждения. Используйте код, показанный справа.');
    return;
  }

  const result = await registerUser({ name, description, email, password });
  if (!result.ok) {
    setFormError(form, storageMessage(result.error));
    return;
  }

  const target = redirectTarget ?? { page: 'profile', portfolioId: '' };
  redirectTarget = null;
  registrationCode = '';
  showToast('Аккаунт создан.');
  navigate(target.page, target.portfolioId);
}

async function submitUserEdit(form) {
  const data = new FormData(form);
  const name = String(data.get('name') ?? '').trim();
  const description = String(data.get('description') ?? '').trim();

  const rawLinks = [1, 2, 3].map((number) => String(data.get(`social${number}`) ?? '').trim());
  const links = rawLinks.map(normalizeUrl);
  const invalidLink = rawLinks.findIndex((value, index) => value && !links[index]);

  if (invalidLink !== -1) {
    setFormError(form, `Ссылка ${invalidLink + 1} должна начинаться с http:// или https://.`);
    return;
  }

  const state = loadState();
  state.user = {
    ...state.user,
    name,
    description,
    social1: links[0],
    social2: links[1],
    social3: links[2],
  };

  const result = await saveState(state);
  if (!result.ok) {
    setFormError(form, storageMessage(result.error));
    return;
  }

  showToast('Профиль обновлён.');
  navigate('profile');
}

async function submitPortfolio(form) {
  const data = new FormData(form);
  const title = String(data.get('title') ?? '').trim();
  const description = String(data.get('description') ?? '').trim();
  const portfolioId = String(data.get('portfolioId') ?? '');
  const state = loadState();

  let portfolio = findPortfolio(state, portfolioId);
  if (!portfolio) {
    portfolio = createPortfolio();
    state.portfolios.unshift(portfolio);
  }

  portfolio.title = title;
  portfolio.description = description;

  for (const field of ['background', 'audio', 'banner']) {
    const file = data.get(field);
    if (!(file instanceof File) || file.size === 0) {
      continue;
    }

    const isImage = IMAGE_FIELDS.has(field);
    const expectedType = isImage ? 'image/' : 'audio/';

    if (!file.type.startsWith(expectedType)) {
      setFormError(form, `Файл для поля «${FILE_LABELS[field]}» имеет неверный формат.`);
      return;
    }

    const limit = isImage ? MAX_IMAGE_FILE_SIZE : MAX_AUDIO_FILE_SIZE;
    if (file.size > limit) {
      setFormError(
        form,
        `Файл «${file.name}» слишком большой (максимум ${formatFileSize(limit)}).`,
      );
      return;
    }

    try {
      portfolio[field] = isImage
        ? await readImage(file, 1600)
        : await readFileAsDataUrl(file);
      portfolio[`${field}Name`] = file.name;
    } catch {
      setFormError(form, `Не удалось прочитать файл «${file.name}».`);
      return;
    }
  }

  const removedPhotoIds = new Set(data.getAll('removePhotos').map(String));
  if (removedPhotoIds.size > 0) {
    portfolio.photos = portfolio.photos.filter((photo) => !removedPhotoIds.has(photo.id));
  }

  for (const file of data.getAll('photos')) {
    if (!(file instanceof File) || file.size === 0) {
      continue;
    }

    if (!file.type.startsWith('image/')) {
      setFormError(form, `Файл «${file.name}» не является изображением.`);
      return;
    }

    if (file.size > MAX_IMAGE_FILE_SIZE) {
      setFormError(
        form,
        `Файл «${file.name}» слишком большой (максимум ${formatFileSize(MAX_IMAGE_FILE_SIZE)}).`,
      );
      return;
    }

    try {
      portfolio.photos.push({
        id: createId(),
        src: await readImage(file, GALLERY_IMAGE_MAX_SIDE),
        name: file.name,
      });
    } catch {
      setFormError(form, `Не удалось прочитать файл «${file.name}».`);
      return;
    }
  }

  portfolio.updatedAt = Date.now();

  const result = await saveState(state);
  if (!result.ok) {
    setFormError(form, storageMessage(result.error));
    return;
  }

  showToast('Портфолио сохранено.');
  navigate('public', portfolio.id);
}

async function uploadAvatar(input, file) {
  if (!file.type.startsWith('image/')) {
    showToast('Для аватара нужно выбрать изображение.', 'error');
    input.value = '';
    return;
  }

  if (file.size > MAX_IMAGE_FILE_SIZE) {
    showToast(`Изображение слишком большое (максимум ${formatFileSize(MAX_IMAGE_FILE_SIZE)}).`, 'error');
    input.value = '';
    return;
  }

  try {
    const avatar = await readImage(file, 480);
    const state = loadState();
    state.user.avatar = avatar;

    const result = await saveState(state);
    if (!result.ok) {
      showToast(storageMessage(result.error), 'error');
      input.value = '';
      return;
    }

    showToast('Аватар обновлён.');
    render();
  } catch {
    showToast('Не удалось обработать изображение.', 'error');
    input.value = '';
  }
}

async function handleAction(action, dataset) {
  switch (action) {
    case 'logout':
      await endSession();
      redirectTarget = null;
      registrationCode = '';
      showToast('Вы вышли из аккаунта.');
      navigate('home');
      break;

    case 'delete-portfolio': {
      if (!dataset.portfolioId) {
        return;
      }

      if (!window.confirm('Удалить это портфолио? Это действие нельзя отменить.')) {
        return;
      }

      const result = await deletePortfolio(dataset.portfolioId);
      if (!result.ok) {
        showToast(storageMessage(result.error), 'error');
        return;
      }

      showToast('Портфолио удалено.');
      render();
      break;
    }

    default:
      break;
  }
}

document.addEventListener('click', async (event) => {
  if (!(event.target instanceof Element)) {
    return;
  }

  const removePhotoButton = event.target.closest('[data-remove-photo]');
  if (removePhotoButton) {
    event.preventDefault();

    const form = removePhotoButton.closest('form[data-form="portfolio"]');
    const photoCard = removePhotoButton.closest('[data-photo-card]');

    if (!form || !photoCard) {
      return;
    }

    if (!window.confirm('Удалить это изображение? Изменение применится после сохранения.')) {
      return;
    }

    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'removePhotos';
    hidden.value = removePhotoButton.dataset.removePhoto;
    form.append(hidden);
    photoCard.remove();
    return;
  }

  const pageButton = event.target.closest('[data-page]');
  if (pageButton) {
    event.preventDefault();
    navigate(pageButton.dataset.page, pageButton.dataset.portfolioId ?? '');
    return;
  }

  const actionButton = event.target.closest('[data-action]');
  if (actionButton) {
    event.preventDefault();
    await handleAction(actionButton.dataset.action, actionButton.dataset);
  }
});

document.addEventListener('change', (event) => {
  const input = event.target;
  if (!(input instanceof HTMLInputElement) || input.type !== 'file') {
    return;
  }

  const files = Array.from(input.files ?? []);
  if (!files.length) {
    return;
  }

  if (input.classList.contains('avatar-input')) {
    void uploadAvatar(input, files[0]);
    return;
  }

  const hint = input.closest('label')?.querySelector('[data-file-name]');
  if (hint) {
    const totalSize = files.reduce((sum, file) => sum + file.size, 0);
    hint.textContent = files.length === 1
      ? `${files[0].name} · ${formatFileSize(totalSize)}`
      : `Выбрано файлов: ${files.length} · ${formatFileSize(totalSize)}`;
  }
});

document.addEventListener('submit', async (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement) || !form.dataset.form) {
    return;
  }

  event.preventDefault();

  const submitter = event.submitter;
  clearFormError(form);
  setFormBusy(form, submitter, true);

  try {
    switch (form.dataset.form) {
      case 'login':
        await submitLogin(form);
        break;
      case 'register':
        await submitRegistration(form);
        break;
      case 'user-edit':
        await submitUserEdit(form);
        break;
      case 'portfolio':
        await submitPortfolio(form);
        break;
      default:
        break;
    }
  } catch (error) {
    console.error(error);
    setFormError(form, 'Что-то пошло не так. Попробуйте ещё раз.');
  } finally {
    setFormBusy(form, submitter, false);
  }
});

window.addEventListener('hashchange', render);

try {
  await initStore();
} catch (error) {
  console.error(error);
  showToast('Сервер недоступен. Запустите npm run server.', 'error');
}

render();
