/** Reusable pieces of the interface: header, cards, toasts and form helpers. */

import { isLoggedIn } from './store.js';

const PUBLIC_LINKS = [
  ['social', '{social media}'],
  ['about', '{About Us}'],
];

function navButton([page, label], activePage) {
  const current = page === activePage ? ' aria-current="page"' : '';
  return `<button type="button" data-page="${page}"${current}>${label}</button>`;
}

export function renderHeader(activePage) {
  const authenticated = isLoggedIn();

  const primaryLinks = authenticated
    ? [
        ['home', '{Home}'],
        ['profile', '{Profile}'],
        ['editor', '{Create Profile}'],
      ]
    : [
        ['home', '{Home}'],
        ['login', '{Log in}'],
        ['register', '{Register}'],
        ['editor', '{Create Profile}'],
      ];

  const accountButton = authenticated
    ? '<button type="button" data-action="logout">{Log out}</button>'
    : '';

  return `
    <header class="site-header">
      ${primaryLinks.map((link) => navButton(link, activePage)).join('')}
      <span class="spacer" aria-hidden="true"></span>
      ${PUBLIC_LINKS.map((link) => navButton(link, activePage)).join('')}
      ${accountButton}
    </header>
  `;
}

/** Wrap content in the bordered panel used all over the design. */
export function card(content, className = '') {
  const classes = ['panel', className.trim()].filter(Boolean).join(' ');
  return `<section class="${classes}">${content}</section>`;
}

let toastStack = null;

export function showToast(message, type = 'info') {
  if (!toastStack) {
    toastStack = document.createElement('div');
    toastStack.className = 'toast-stack';
    document.body.append(toastStack);
  }

  const toast = document.createElement('div');
  toast.className = `toast${type === 'error' ? ' toast--error' : ''}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  toast.textContent = message;
  toastStack.append(toast);

  window.setTimeout(() => {
    toast.remove();

    if (toastStack && !toastStack.childElementCount) {
      toastStack.remove();
      toastStack = null;
    }
  }, 4200);
}

export function setFormError(form, message) {
  let box = form.querySelector('.form-error');

  if (!box) {
    box = document.createElement('p');
    box.className = 'form-error';
    box.setAttribute('role', 'alert');
    form.append(box);
  }

  box.textContent = message;
}

export function clearFormError(form) {
  const box = form.querySelector('.form-error');
  if (box) {
    box.textContent = '';
  }
}

/**
 * Disable the submit button(s) while an async handler is running.
 * The auth form's submit button sits outside the <form>, so we also look up
 * buttons connected through the `form` attribute.
 */
export function setFormBusy(form, submitter, busy) {
  form.setAttribute('aria-busy', String(busy));

  const buttons = new Set(form.querySelectorAll('button[type="submit"]'));
  if (submitter) {
    buttons.add(submitter);
  }

  if (form.id) {
    for (const button of document.querySelectorAll(`button[form="${form.id}"]`)) {
      buttons.add(button);
    }
  }

  for (const button of buttons) {
    button.disabled = busy;
  }
}
