/**
 * Клиентское хранилище поверх Express API.
 *
 * Состояние загружается один раз в память (initStore), поэтому шаблоны
 * страниц остаются синхронными. Все изменения уходят на сервер и в MySQL.
 */

function createEmptyUser() {
  return {
    name: '',
    description: '',
    email: '',
    passwordHash: '',
    avatar: '',
    social1: '',
    social2: '',
    social3: '',
  };
}

/** Короткий уникальный id для портфолио и фотографий. */
export function createId() {
  if (globalThis.crypto?.randomUUID) {
    return crypto.randomUUID();
  }

  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

/** Новое несохранённое портфолио. */
export function createPortfolio() {
  return {
    id: createId(),
    title: '',
    description: '',
    background: '',
    backgroundName: '',
    banner: '',
    bannerName: '',
    audio: '',
    audioName: '',
    photos: [],
    updatedAt: Date.now(),
  };
}

function createEmptyState() {
  return {
    user: createEmptyUser(),
    portfolios: [],
  };
}

function normalizePhoto(raw) {
  const source = typeof raw === 'string' ? raw : raw?.src;

  if (typeof source !== 'string' || !source) {
    return null;
  }

  return {
    id: typeof raw?.id === 'string' && raw.id ? raw.id : createId(),
    src: source,
    name: typeof raw?.name === 'string' ? raw.name : '',
  };
}

function normalizePortfolio(raw, usedIds) {
  if (!raw || typeof raw !== 'object') {
    return null;
  }

  const portfolio = createPortfolio();

  let id = typeof raw.id === 'string' && raw.id ? raw.id : portfolio.id;
  while (usedIds.has(id)) {
    id = createId();
  }
  usedIds.add(id);
  portfolio.id = id;

  for (const key of [
    'title',
    'description',
    'background',
    'backgroundName',
    'banner',
    'bannerName',
    'audio',
    'audioName',
  ]) {
    if (typeof raw[key] === 'string') {
      portfolio[key] = raw[key];
    }
  }

  if (Array.isArray(raw.photos)) {
    const photoIds = new Set();

    portfolio.photos = raw.photos
      .map(normalizePhoto)
      .filter(Boolean)
      .map((photo) => {
        if (photoIds.has(photo.id)) {
          photo.id = createId();
        }
        photoIds.add(photo.id);
        return photo;
      });
  }

  // Старые данные хранили одно picture — переносим его в галерею.
  if (!portfolio.photos.length && typeof raw.picture === 'string' && raw.picture) {
    portfolio.photos.push({
      id: createId(),
      src: raw.picture,
      name: typeof raw.pictureName === 'string' ? raw.pictureName : '',
    });
  }

  portfolio.updatedAt = Number.isFinite(raw.updatedAt) ? raw.updatedAt : Date.now();

  return portfolio;
}

function hasContent(portfolio) {
  return Boolean(
    portfolio.title
      || portfolio.description
      || portfolio.background
      || portfolio.banner
      || portfolio.audio
      || portfolio.photos.length,
  );
}

function normalizeState(raw) {
  const state = createEmptyState();

  if (!raw || typeof raw !== 'object') {
    return state;
  }

  for (const key of Object.keys(state.user)) {
    if (typeof raw.user?.[key] === 'string') {
      state.user[key] = raw.user[key];
    }
  }

  const usedIds = new Set();

  if (Array.isArray(raw.portfolios)) {
    state.portfolios = raw.portfolios
      .map((portfolio) => normalizePortfolio(portfolio, usedIds))
      .filter((portfolio) => portfolio && hasContent(portfolio));
  } else if (raw.portfolio) {
    const portfolio = normalizePortfolio(raw.portfolio, usedIds);
    if (portfolio && hasContent(portfolio)) {
      state.portfolios = [portfolio];
    }
  }

  return state;
}

let state = createEmptyState();
let authenticated = false;

/** Состояние из памяти. Шаблоны используют его синхронно. */
export function loadState() {
  return state;
}

export function isLoggedIn() {
  return authenticated;
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers,
    },
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    return { ok: false, error: data.error || `Ошибка сервера (${response.status}).` };
  }

  return { ok: true, data };
}

/** Загрузить пользователя и портфолио с сервера при старте сайта. */
export async function initStore() {
  const result = await request('/api/state');

  if (!result.ok) {
    throw new Error(result.error);
  }

  authenticated = Boolean(result.data.loggedIn);
  state = normalizeState(result.data);
  return state;
}

export async function registerUser({ name, description, email, password }) {
  const result = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, description, email, password }),
  });

  if (!result.ok) {
    return result;
  }

  await initStore();
  return { ok: true };
}

export async function authenticate(identifier, password) {
  const result = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  });

  if (!result.ok) {
    return result;
  }

  await initStore();
  return { ok: true };
}

export async function endSession() {
  await request('/api/auth/logout', { method: 'POST' });
  authenticated = false;
  state = createEmptyState();
}

export async function saveState(nextState) {
  const result = await request('/api/state', {
    method: 'PUT',
    body: JSON.stringify(nextState),
  });

  if (result.ok) {
    state = normalizeState(nextState);
  }

  return result;
}

export function findPortfolio(currentState, portfolioId) {
  if (!portfolioId) {
    return null;
  }

  return currentState.portfolios.find((portfolio) => portfolio.id === portfolioId) ?? null;
}

export async function deletePortfolio(portfolioId) {
  const result = await request(`/api/portfolios/${encodeURIComponent(portfolioId)}`, {
    method: 'DELETE',
  });

  if (result.ok) {
    state = {
      ...state,
      portfolios: state.portfolios.filter((portfolio) => portfolio.id !== portfolioId),
    };
  }

  return result;
}
