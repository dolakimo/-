/**
 * Small helpers used by the views and the event handlers.
 * Everything here is framework-free on purpose: the project is a single-page
 * app built on plain ES modules and the DOM.
 */

const HTML_ENTITIES = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

/**
 * Escape a value before putting it into an HTML template.
 * Always use this for anything that comes from localStorage or a form.
 */
export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => HTML_ENTITIES[character]);
}

/**
 * Turn user input into an absolute http(s) URL.
 * Returns an empty string when the value is empty or uses another protocol.
 */
export function normalizeUrl(value) {
  const raw = String(value ?? '').trim();
  if (!raw) {
    return '';
  }

  const withProtocol = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`;

  try {
    const url = new URL(withProtocol);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : '';
  } catch {
    return '';
  }
}

/**
 * Allow only sources that are safe to use in <img src> or <audio src>.
 * Uploaded files are stored as base64 data URLs, so anything else is ignored.
 */
export function safeMediaSource(value, kind = 'image') {
  const source = String(value ?? '').trim();
  if (!source) {
    return '';
  }

  const dataUrl = new RegExp(`^data:${kind}/[a-z0-9.+-]+;base64,[a-z0-9+/=\\s]+$`, 'i');
  if (dataUrl.test(source) || /^blob:/i.test(source)) {
    return source;
  }

  try {
    const url = new URL(source);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : '';
  } catch {
    return '';
  }
}

/** Read a File object as a data URL. */
export function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.addEventListener('load', () => resolve(String(reader.result)));
    reader.addEventListener('error', () => {
      reject(reader.error ?? new Error('Не удалось прочитать файл'));
    });

    reader.readAsDataURL(file);
  });
}

/** Decode a data URL (or any URL) into an Image element. */
export function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();

    image.addEventListener('load', () => resolve(image));
    image.addEventListener('error', () => reject(new Error('Не удалось загрузить изображение')));

    image.src = source;
  });
}

/**
 * Read an image and, when it is large, downscale it with a canvas.
 * This keeps localStorage from filling up after a few uploads.
 */
export async function readImage(file, maxSide = 1400) {
  const original = await readFileAsDataUrl(file);

  // SVG and GIF are left untouched: canvas would drop their vector data/
  // animation, and small raster images do not need to be re-encoded.
  const compressibleTypes = /^image\/(jpeg|png|webp|bmp|avif)$/i;
  if (!compressibleTypes.test(file.type)) {
    return original;
  }

  try {
    const image = await loadImage(original);
    const needsResize = Math.max(image.naturalWidth, image.naturalHeight) > maxSide;
    const needsReencode = file.size > 300 * 1024;

    if (!needsResize && !needsReencode) {
      return original;
    }

    const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
    const width = Math.max(1, Math.round(image.naturalWidth * scale));
    const height = Math.max(1, Math.round(image.naturalHeight * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext('2d');
    if (!context) {
      return original;
    }

    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    context.drawImage(image, 0, 0, width, height);

    const compressed = canvas.toDataURL('image/webp', 0.85);
    return compressed.length < original.length ? compressed : original;
  } catch {
    return original;
  }
}

/** Human readable file size, used in hints and error messages. */
export function formatFileSize(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return '0 Б';
  }

  const units = ['Б', 'КБ', 'МБ'];
  const exponent = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** exponent;

  return `${value.toFixed(exponent === 0 ? 0 : 1)} ${units[exponent]}`;
}
