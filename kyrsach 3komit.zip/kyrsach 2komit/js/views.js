/** All page templates. Each function receives the normalised app state. */

import heroImage from '../assets/hero.png';
import { card } from './components.js';
import { findPortfolio } from './store.js';
import { escapeHtml, normalizeUrl, safeMediaSource } from './utils.js';

const TAGLINES = [
  'your style = our problem',
  'your “I” for others “they”',
];

export function renderHome() {
  return `
    <div class="home page">
      <div class="label profile-label">{Your Profile}</div>
      <div class="label update-label">{Last Update’s}</div>

      ${card(`
        <div class="keywords">popular<br>different<br>interesting<br>interactive</div>
      `, 'profile-card')}

      ${card(`
        <div class="updates">
          Create Site)))<br>
          <i aria-hidden="true">Create Site)))</i><br>
          <em aria-hidden="true">Create Site)))</em>
        </div>
      `, 'update-card')}

      <img class="hero" src="${heroImage}" alt="Profile illustration">

      <div class="statement">
        <span>${TAGLINES[0]}</span>
        <b>Console.WriteLine(“ProfileView”)</b>
        <span>${TAGLINES[1]}</span>
      </div>

      <button type="button" class="create" data-page="editor">CREATE PORTFOLIO</button>
    </div>
  `;
}

export function renderAuth(mode, state, verificationCode = '') {
  const isRegister = mode === 'register';
  // A fresh state always has a user, but an empty object keeps the form stable
  // if an older stored value is missing it.
  const user = state.user ?? {};
  const submitLabel = isRegister ? 'Complete Registration' : 'Complete Entry';

  return `
    <div class="auth page">
      <img class="auth-art" src="${heroImage}" alt="" aria-hidden="true">

      <form
        id="auth-form"
        class="auth-form${isRegister ? ' auth-form--register' : ''}"
        data-form="${isRegister ? 'register' : 'login'}"
      >
        <label>
          Let Name =
          <input
            name="name"
            required
            minlength="2"
            maxlength="40"
            autocomplete="username"
            value="${escapeHtml(user.name)}"
          >
        </label>

        <label>
          Let Password =
          <input
            name="password"
            type="password"
            required
            minlength="6"
            autocomplete="${isRegister ? 'new-password' : 'current-password'}"
          >
        </label>

        ${isRegister ? `
          <label class="auth-description">
            Let Description =
            <textarea
              name="description"
              required
              minlength="10"
              maxlength="500"
            >${escapeHtml(user.description)}</textarea>
          </label>

          <label class="auth-email">
            Let Gmail =
            <input
              name="email"
              type="email"
              required
              maxlength="120"
              autocomplete="email"
              value="${escapeHtml(user.email)}"
            >
          </label>

          <aside class="verification">
            <span>Code From Gmail</span>
            <output class="verification-code" data-demo-code>${escapeHtml(verificationCode)}</output>
            <input
              name="code"
              required
              inputmode="numeric"
              pattern="[0-9]{4}"
              maxlength="4"
              placeholder="0000"
              autocomplete="one-time-code"
              aria-label="Verification code"
            >
            <small class="field-hint">Demo only: use the code shown above.</small>
          </aside>
        ` : ''}

        <p class="form-error" role="alert"></p>
      </form>

      <div class="auth-actions">
        <button type="button" class="return" data-page="home">{Return}</button>
        <button type="submit" form="auth-form" class="complete">
          &lt;button&gt;${submitLabel}&lt;/button&gt;
        </button>
      </div>
    </div>
  `;
}

export function renderProfile(state) {
  const { user } = state;
  const avatar = safeMediaSource(user.avatar, 'image');
  const portfolios = [...state.portfolios].sort((a, b) => b.updatedAt - a.updatedAt);

  const portfolioList = portfolios.length > 0
    ? portfolios.map((portfolio, index) => `
        <p>
          <button
            type="button"
            class="portfolio-link"
            data-page="public"
            data-portfolio-id="${escapeHtml(portfolio.id)}"
          >
            ${escapeHtml(portfolio.title || `Portfolio ${index + 1}`)}
          </button>
          <span>
            <button
              type="button"
              data-page="editor"
              data-portfolio-id="${escapeHtml(portfolio.id)}"
            >{Edit portfolio}</button>
            <button
              type="button"
              class="delete"
              data-action="delete-portfolio"
              data-portfolio-id="${escapeHtml(portfolio.id)}"
            >{Delete}</button>
          </span>
        </p>
      `).join('')
    : '<p>Портфолио пока не создано.</p>';

  return `
    <div class="dashboard page">
      <h1>Console.WriteLine(“${escapeHtml(user.name || 'NameProfile')}”)</h1>

      ${card(`
        <p>{Name}: ${escapeHtml(user.name || '—')}</p>
        <p>{Description}: ${escapeHtml(user.description || '—')}</p>
        <p>{Gmail}: ${escapeHtml(user.email || '—')}</p>
        <button type="button" data-page="user-edit">{Edit}</button>
      `, 'identity')}

      ${card(`
        <p>Public Class Subscription_Limit{</p>
        <strong>LITE</strong>
        <b>{20.Token}</b>
        <p>}</p>
      `, 'subscription')}

      ${card(`
        <label class="avatar-upload">
          ${avatar
            ? `<img src="${escapeHtml(avatar)}" alt="Avatar of ${escapeHtml(user.name || 'user')}">`
            : '<code>&lt;img src="__" alt="avatar"&gt;</code>'}
          <span>Добавить аватар</span>
          <input class="avatar-input" type="file" accept="image/*">
        </label>
      `, 'avatar')}

      ${card(`
        <h2>Your Profiles</h2>
        ${portfolioList}
        <button type="button" class="create-portfolio" data-page="editor">
          {Create ${portfolios.length > 0 ? 'another ' : ''}portfolio}
        </button>
      `, 'profile-list')}
    </div>
  `;
}

export function renderUserEdit(state) {
  const { user } = state;

  const socialFields = [1, 2, 3].map((number) => `
    <label>
      Link ${number}
      <input
        name="social${number}"
        type="url"
        placeholder="https://…"
        value="${escapeHtml(user[`social${number}`])}"
      >
    </label>
  `).join('');

  return `
    <div class="user-edit page">
      <h1>Console.WriteLine(“EditUser”)</h1>

      <form class="user-edit-form" data-form="user-edit">
        <label>
          {Name}
          <input
            name="name"
            required
            minlength="2"
            maxlength="40"
            autocomplete="username"
            value="${escapeHtml(user.name)}"
          >
        </label>

        <label>
          {Description}
          <textarea
            name="description"
            required
            minlength="10"
            maxlength="500"
          >${escapeHtml(user.description)}</textarea>
        </label>

        <fieldset>
          <legend>{Social links — max 3}</legend>
          ${socialFields}
        </fieldset>

        <p class="form-error" role="alert"></p>
        <button type="submit">&lt;button&gt;Save&lt;/button&gt;</button>
      </form>
    </div>
  `;
}

const UPLOAD_FIELDS = [
  { name: 'background', label: '{Enter Your Background}', accept: 'image/*' },
  { name: 'photos', label: '{Enter Your Pic.Portfolio}', accept: 'image/*', multiple: true },
  { name: 'audio', label: '{Enter Your Audio.Portfolio}', accept: 'audio/*' },
  { name: 'banner', label: '{Enter Your Banner}', accept: 'image/*' },
];

function uploadCard(field, portfolio) {
  const storedName = field.multiple
    ? `Можно выбрать несколько · в портфолио: ${portfolio.photos.length}`
    : portfolio[`${field.name}Name`] || 'Файл не выбран';

  return card(`
    <label>
      ${field.label}
      <span class="upload-control">
        ${field.multiple ? 'Прикрепить несколько' : 'Прикрепить'}
        <input
          name="${field.name}"
          type="file"
          accept="${field.accept}"${field.multiple ? ' multiple' : ''}
        >
      </span>
      <small data-file-name>${escapeHtml(storedName)}</small>
    </label>
  `);
}

export function renderEditor(state, portfolioId = '') {
  const existing = findPortfolio(state, portfolioId);
  const portfolio = existing ?? {
    id: '',
    title: '',
    description: '',
    background: '',
    backgroundName: '',
    banner: '',
    bannerName: '',
    audio: '',
    audioName: '',
    photos: [],
  };

  const photos = portfolio.photos
    .map((photo) => ({ ...photo, src: safeMediaSource(photo.src, 'image') }))
    .filter((photo) => photo.src);

  return `
    <div class="editor page">
      <h1>Console.WriteLine(“${existing ? 'EditPortfolio' : 'CreatePortfolio'}”)</h1>

      <form class="editor-grid" data-form="portfolio">
        <input type="hidden" name="portfolioId" value="${escapeHtml(existing?.id ?? '')}">

        ${uploadCard(UPLOAD_FIELDS[0], portfolio)}
        ${uploadCard(UPLOAD_FIELDS[1], portfolio)}
        ${uploadCard(UPLOAD_FIELDS[2], portfolio)}

        ${card(`
          <label class="text-field">
            {Portfolio name}
            <input
              name="title"
              required
              minlength="2"
              maxlength="60"
              value="${escapeHtml(portfolio.title)}"
            >
          </label>
          <label>
            {Write Your description}
            <textarea
              name="description"
              required
              minlength="10"
              maxlength="700"
            >${escapeHtml(portfolio.description)}</textarea>
          </label>
        `, 'details-card')}

        ${uploadCard(UPLOAD_FIELDS[3], portfolio)}

        ${photos.length > 0 ? card(`
          <h2>Фотографии портфолио</h2>
          <div class="photo-library">
            ${photos.map((photo) => `
              <figure class="photo-item" data-photo-card>
                <img
                  src="${escapeHtml(photo.src)}"
                  alt="${escapeHtml(photo.name || 'Фото портфолио')}"
                >
                <button
                  type="button"
                  class="photo-remove"
                  data-remove-photo="${escapeHtml(photo.id)}"
                  aria-label="Удалить изображение ${escapeHtml(photo.name || '')}"
                >×</button>
              </figure>
            `).join('')}
          </div>
          <p class="field-hint">Удаление применится после нажатия «Done».</p>
        `, 'photo-library-card') : ''}

        ${card(`
          <p class="field-hint">Файлы сохраняются в базе данных.</p>
          <button class="done" type="submit">&lt;button&gt;Done&lt;/button&gt;</button>
        `, 'submit-card')}

        <p class="form-error" role="alert"></p>
      </form>
    </div>
  `;
}

export function renderPublic(state, portfolioId = '') {
  const { user } = state;
  const portfolio = findPortfolio(state, portfolioId) ?? state.portfolios[0] ?? null;

  if (!portfolio) {
    return `
      <div class="public public--empty page">
        ${card(`
          <h1>{No portfolio yet}</h1>
          <p>Создайте портфолио, чтобы увидеть его здесь.</p>
          <button type="button" class="empty-create" data-page="editor">CREATE PORTFOLIO</button>
        `, 'empty-portfolio')}
      </div>
    `;
  }

  const background = safeMediaSource(portfolio.background, 'image');
  const avatar = safeMediaSource(user.avatar, 'image');
  const banner = safeMediaSource(portfolio.banner, 'image');
  const audio = safeMediaSource(portfolio.audio, 'audio');

  const photos = portfolio.photos
    .map((photo) => ({
      src: safeMediaSource(photo.src, 'image'),
      name: photo.name,
    }))
    .filter((photo) => photo.src);

  const socialLinks = [
    { label: 'tg', url: normalizeUrl(user.social1) },
    { label: 'vk', url: normalizeUrl(user.social2) },
    { label: 'yt', url: normalizeUrl(user.social3) },
  ].filter(({ url }) => url);

  const placeholderCount = Math.max(0, 5 - photos.length);
  const placeholderArt = card('{Art’s}', 'work');

  const portfolioSwitcher = state.portfolios.length > 1
    ? `
      <nav class="portfolio-switcher" aria-label="Другие портфолио">
        ${state.portfolios.map((item) => `
          <button
            type="button"
            data-page="public"
            data-portfolio-id="${escapeHtml(item.id)}"
            ${item.id === portfolio.id ? 'aria-current="page"' : ''}
          >${escapeHtml(item.title || 'Без названия')}</button>
        `).join('')}
      </nav>
    `
    : '';

  return `
    <div class="public page">
      ${background ? `
        <img
          class="public-background"
          src="${escapeHtml(background)}"
          alt=""
          aria-hidden="true"
        >
      ` : ''}

      <div class="avatar-box">
        ${avatar
          ? `<img src="${escapeHtml(avatar)}" alt="Avatar of ${escapeHtml(user.name || 'user')}">`
          : '{}'}
      </div>

      <div class="socials">
        ${socialLinks.length > 0
          ? socialLinks.map(({ label, url }) => `
              <a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${label}</a>
            `).join('')
          : '<span>+ links</span>'}
      </div>

      ${card(escapeHtml(user.name || '{Name}'), 'name')}
      ${card(escapeHtml(user.description || '{Description}'), 'description')}
      ${card(banner ? `<img src="${escapeHtml(banner)}" alt="Portfolio banner">` : '{Banner}', 'banner')}
      ${card(
        audio
          ? `<audio controls preload="metadata" src="${escapeHtml(audio)}"></audio>`
          : '{Audio}',
        'audio-card',
      )}

      <section class="portfolio-gallery">
        <div class="portfolio-gallery-head">
          <h2>${escapeHtml(portfolio.title || 'Portfolio')}</h2>
          ${portfolioSwitcher}
        </div>

        <div class="gallery-grid">
          ${photos.map((photo) => card(`
            <img
              src="${escapeHtml(photo.src)}"
              alt="${escapeHtml(photo.name || 'Portfolio artwork')}"
            >
          `, 'work')).join('')}
          ${Array.from({ length: placeholderCount }, () => placeholderArt).join('')}
        </div>
      </section>

      ${portfolio.description
        ? `<p class="portfolio-copy">${escapeHtml(portfolio.description)}</p>`
        : ''}
    </div>
  `;
}

export function renderSocial() {
  return `
    <div class="info page">
      <h1>{social media}</h1>
      <div class="wide">
        <span>{YouTube}</span>
        <span>{Telegram}</span>
        <span>{Twitter}</span>
      </div>
    </div>
  `;
}

export function renderAbout() {
  return `
    <div class="info page">
      <h1>{About Us}</h1>
      <div class="wide about">
        <p>
          ProfileView is a small space for work that feels personal, different and interactive.
          Create a portfolio, add your links and share it in a couple of minutes.
        </p>
      </div>
    </div>
  `;
}
