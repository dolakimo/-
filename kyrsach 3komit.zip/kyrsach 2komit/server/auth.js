import crypto from 'node:crypto';
import { pool } from './db.js';

const COOKIE_NAME = 'pv_session';
const SESSION_DAYS = 7;
const SESSION_MS = SESSION_DAYS * 24 * 60 * 60 * 1000;

/** Создать сессию в БД и положить её id в httpOnly-cookie. */
export async function startSession(res, userId) {
  const id = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + SESSION_MS);

  await pool.execute(
    'INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)',
    [id, userId, expiresAt],
  );

  res.cookie(COOKIE_NAME, id, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: SESSION_MS,
    secure: process.env.NODE_ENV === 'production',
  });
}

/** Удалить сессию из БД и из cookie. */
export async function endSession(req, res) {
  const id = req.cookies?.[COOKIE_NAME];

  if (id) {
    await pool.execute('DELETE FROM sessions WHERE id = ?', [id]);
  }

  res.clearCookie(COOKIE_NAME);
}

/** Вернуть id пользователя по cookie или null. */
export async function getUserId(req) {
  const id = req.cookies?.[COOKIE_NAME];
  if (!id) {
    return null;
  }

  const [rows] = await pool.execute(
    'SELECT user_id FROM sessions WHERE id = ? AND expires_at > NOW() LIMIT 1',
    [id],
  );

  return rows[0]?.user_id ?? null;
}

/** Middleware: пропускает только вошедшего пользователя. */
export async function requireAuth(req, res, next) {
  try {
    const userId = await getUserId(req);
    if (!userId) {
      return res.status(401).json({ error: 'Сначала войдите в аккаунт.' });
    }

    req.userId = userId;
    return next();
  } catch (error) {
    return next(error);
  }
}

/** Удалить просроченные сессии. */
export async function clearExpiredSessions() {
  await pool.execute('DELETE FROM sessions WHERE expires_at <= NOW()');
}
