import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import { pool } from './db.js';
import {
  clearExpiredSessions,
  endSession,
  getUserId,
  requireAuth,
  startSession,
} from './auth.js';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PORT = Number(process.env.PORT || 3000);
const app = express();

app.use(express.json({ limit: '64mb' }));
app.use(cookieParser());

const EMPTY_USER = {
  name: '',
  description: '',
  email: '',
  avatar: '',
  social1: '',
  social2: '',
  social3: '',
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function newId() {
  return crypto.randomUUID();
}

function safeId(value) {
  return typeof value === 'string' && UUID_RE.test(value) ? value : newId();
}

function shortText(value, max) {
  return String(value ?? '').trim().slice(0, max);
}

function longText(value) {
  return typeof value === 'string' ? value : '';
}

/* ------------------------------- Регистрация ------------------------------ */

app.post('/api/auth/register', async (req, res, next) => {
  try {
    const name = shortText(req.body?.name, 60);
    const description = shortText(req.body?.description, 500);
    const email = shortText(req.body?.email, 120);
    const password = String(req.body?.password ?? '');

    if (name.length < 2) {
      return res.status(400).json({ error: 'Имя должно быть не короче 2 символов.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Пароль должен быть не короче 6 символов.' });
    }
    if (description.length < 10) {
      return res.status(400).json({ error: 'Описание должно быть не короче 10 символов.' });
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      return res.status(400).json({ error: 'Введите корректный email.' });
    }

    const [existing] = await pool.execute(
      'SELECT id FROM `users` WHERE `login` = ? LIMIT 1',
      [name],
    );
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Такое имя уже занято.' });
    }

    const userId = newId();
    const passwordHash = await bcrypt.hash(password, 10);
    const connection = await pool.getConnection();

    try {
      await connection.beginTransaction();
      await connection.execute(
        'INSERT INTO `users` (`id`, `login`, `password_hash`) VALUES (?, ?, ?)',
        [userId, name, passwordHash],
      );
      await connection.execute(
        'INSERT INTO `Profiles` (`id`, `user_id`, `name`, `description`, `email`) VALUES (?, ?, ?, ?, ?)',
        [newId(), userId, name, description, email],
      );
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    await clearExpiredSessions();
    await startSession(res, userId);
    return res.status(201).json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

/* ---------------------------------- Вход ---------------------------------- */

app.post('/api/auth/login', async (req, res, next) => {
  try {
    const identifier = shortText(req.body?.identifier, 120);
    const password = String(req.body?.password ?? '');

    if (!identifier || !password) {
      return res.status(400).json({ error: 'Введите имя и пароль.' });
    }

    const [rows] = await pool.execute(
      `SELECT u.id, u.password_hash
       FROM users u
       JOIN \`Profiles\` p ON p.user_id = u.id
       WHERE u.login = ? OR p.email = ?
       LIMIT 1`,
      [identifier, identifier],
    );

    const user = rows[0];
    const passwordOk = user ? await bcrypt.compare(password, user.password_hash) : false;

    if (!user || !passwordOk) {
      return res.status(401).json({ error: 'Неверное имя или пароль.' });
    }

    await clearExpiredSessions();
    await startSession(res, user.id);
    return res.json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

/* --------------------------------- Выход ---------------------------------- */

app.post('/api/auth/logout', async (req, res, next) => {
  try {
    await endSession(req, res);
    return res.json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

/* ------------------------- Загрузка состояния сайта ------------------------ */

app.get('/api/state', async (req, res, next) => {
  try {
    const userId = await getUserId(req);

    if (!userId) {
      return res.json({ loggedIn: false, user: EMPTY_USER, portfolios: [] });
    }

    const [profiles] = await pool.execute(
      'SELECT * FROM `Profiles` WHERE `user_id` = ? LIMIT 1',
      [userId],
    );

    if (!profiles.length) {
      await endSession(req, res);
      return res.json({ loggedIn: false, user: EMPTY_USER, portfolios: [] });
    }

    const profile = profiles[0];
    const [portfolioRows] = await pool.execute(
      'SELECT * FROM `Portfolio` WHERE `user_id` = ? ORDER BY `updated_at` DESC',
      [userId],
    );

    const portfolios = [];

    for (const row of portfolioRows) {
      const [imageRows] = await pool.execute(
        'SELECT `id`, `src`, `name` FROM `Image` WHERE `portfolio_id` = ? ORDER BY `sort_order`, `created_at`',
        [row.id],
      );
      const [audioRows] = await pool.execute(
        'SELECT `src`, `name` FROM `audio` WHERE `portfolio_id` = ? LIMIT 1',
        [row.id],
      );

      portfolios.push({
        id: row.id,
        title: row.title,
        description: row.description,
        background: row.background ?? '',
        backgroundName: row.background_name ?? '',
        banner: row.banner ?? '',
        bannerName: row.banner_name ?? '',
        audio: audioRows[0]?.src ?? '',
        audioName: audioRows[0]?.name ?? '',
        photos: imageRows.map((image) => ({
          id: image.id,
          src: image.src,
          name: image.name ?? '',
        })),
        updatedAt: new Date(row.updated_at).getTime(),
      });
    }

    return res.json({
      loggedIn: true,
      user: {
        name: profile.name,
        description: profile.description,
        email: profile.email,
        avatar: profile.avatar ?? '',
        social1: profile.social1 ?? '',
        social2: profile.social2 ?? '',
        social3: profile.social3 ?? '',
      },
      portfolios,
    });
  } catch (error) {
    return next(error);
  }
});

/* --------------------------- Сохранение состояния ------------------------- */

app.put('/api/state', requireAuth, async (req, res, next) => {
  const user = req.body?.user ?? {};
  const portfolios = Array.isArray(req.body?.portfolios) ? req.body.portfolios : [];
  const name = shortText(user.name, 60);
  const description = shortText(user.description, 500);
  const email = shortText(user.email, 120);

  if (!name) {
    return res.status(400).json({ error: 'Имя не может быть пустым.' });
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    await connection.execute(
      'UPDATE `users` SET `login` = ? WHERE `id` = ?',
      [name, req.userId],
    );
    await connection.execute(
      `UPDATE \`Profiles\`
       SET \`name\` = ?, \`description\` = ?, \`email\` = ?, \`avatar\` = ?,
           \`social1\` = ?, \`social2\` = ?, \`social3\` = ?
       WHERE \`user_id\` = ?`,
      [
        name,
        description,
        email,
        longText(user.avatar),
        longText(user.social1),
        longText(user.social2),
        longText(user.social3),
        req.userId,
      ],
    );

    // Простейший способ синхронизировать портфолио: заменить их целиком.
    // Все связанные Image и audio удалятся каскадно.
    await connection.execute('DELETE FROM `Portfolio` WHERE `user_id` = ?', [req.userId]);

    const usedPortfolioIds = new Set();

    for (const raw of portfolios) {
      let portfolioId = safeId(raw?.id);
      if (usedPortfolioIds.has(portfolioId)) {
        portfolioId = newId();
      }
      usedPortfolioIds.add(portfolioId);

      const updatedAt = Number.isFinite(raw?.updatedAt)
        ? new Date(raw.updatedAt)
        : new Date();

      await connection.execute(
        `INSERT INTO \`Portfolio\`
         (\`id\`, \`user_id\`, \`title\`, \`description\`, \`background\`,
          \`background_name\`, \`banner\`, \`banner_name\`, \`updated_at\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          portfolioId,
          req.userId,
          shortText(raw?.title, 60) || 'Portfolio',
          shortText(raw?.description, 700),
          longText(raw?.background),
          shortText(raw?.backgroundName, 255),
          longText(raw?.banner),
          shortText(raw?.bannerName, 255),
          updatedAt,
        ],
      );

      const photos = Array.isArray(raw?.photos) ? raw.photos : [];
      const usedPhotoIds = new Set();
      let order = 0;

      for (const photo of photos) {
        const src = longText(photo?.src);
        if (!src) {
          continue;
        }

        let photoId = safeId(photo?.id);
        if (usedPhotoIds.has(photoId)) {
          photoId = newId();
        }
        usedPhotoIds.add(photoId);

        await connection.execute(
          'INSERT INTO `Image` (`id`, `portfolio_id`, `src`, `name`, `sort_order`) VALUES (?, ?, ?, ?, ?)',
          [photoId, portfolioId, src, shortText(photo?.name, 255), order],
        );
        order += 1;
      }

      const audioSrc = longText(raw?.audio);
      if (audioSrc) {
        await connection.execute(
          'INSERT INTO `audio` (`id`, `portfolio_id`, `src`, `name`) VALUES (?, ?, ?, ?)',
          [newId(), portfolioId, audioSrc, shortText(raw?.audioName, 255)],
        );
      }
    }

    await connection.commit();
    return res.json({ ok: true });
  } catch (error) {
    await connection.rollback();
    return next(error);
  } finally {
    connection.release();
  }
});

/* ------------------------------ Удаление ---------------------------------- */

app.delete('/api/portfolios/:id', requireAuth, async (req, res, next) => {
  try {
    const [result] = await pool.execute(
      'DELETE FROM `Portfolio` WHERE `id` = ? AND `user_id` = ?',
      [req.params.id, req.userId],
    );

    if (!result.affectedRows) {
      return res.status(404).json({ error: 'Портфолио не найдено.' });
    }

    return res.json({ ok: true });
  } catch (error) {
    return next(error);
  }
});

/* -------------------------- Статика и ошибки ------------------------------ */

const dist = path.join(root, 'dist');

if (fs.existsSync(dist)) {
  app.use(express.static(dist));

  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api')) {
      return res.sendFile(path.join(dist, 'index.html'));
    }
    return next();
  });
}

app.use((error, req, res, next) => {
  console.error(error);

  if (res.headersSent) {
    return next(error);
  }
  if (error.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'Такая запись уже существует.' });
  }
  if (error.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Файлы слишком большие. Выберите файлы поменьше.' });
  }

  return res.status(500).json({ error: 'Ошибка сервера. Проверьте подключение к MySQL.' });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});
