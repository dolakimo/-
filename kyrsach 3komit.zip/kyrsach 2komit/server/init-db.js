import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

const connection = await mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true,
});

const sql = await readFile(path.join(root, 'sql', 'schema.sql'), 'utf8');
await connection.query(sql);
await connection.end();

console.log('База course и таблицы созданы.');
