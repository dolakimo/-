-- База данных для сайта ProfileView.
-- Запуск: npm run db:init (или mysql -u root -p < sql/schema.sql)

CREATE DATABASE IF NOT EXISTS `course`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `course`;

-- Аккаунт для входа.
CREATE TABLE IF NOT EXISTS `users` (
  `id` CHAR(36) NOT NULL,
  `login` VARCHAR(60) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Данные профиля пользователя (имя, описание, ссылки, аватар).
CREATE TABLE IF NOT EXISTS `Profiles` (
  `id` CHAR(36) NOT NULL,
  `user_id` CHAR(36) NOT NULL,
  `name` VARCHAR(60) NOT NULL,
  `description` TEXT NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `avatar` LONGTEXT NULL,
  `social1` VARCHAR(255) NULL,
  `social2` VARCHAR(255) NULL,
  `social3` VARCHAR(255) NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_profiles_user` (`user_id`),
  CONSTRAINT `fk_profiles_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Портфолио пользователя. У одного пользователя их может быть много.
CREATE TABLE IF NOT EXISTS `Portfolio` (
  `id` CHAR(36) NOT NULL,
  `user_id` CHAR(36) NOT NULL,
  `title` VARCHAR(60) NOT NULL,
  `description` TEXT NOT NULL,
  `background` LONGTEXT NULL,
  `background_name` VARCHAR(255) NULL,
  `banner` LONGTEXT NULL,
  `banner_name` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_portfolio_user` (`user_id`),
  CONSTRAINT `fk_portfolio_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Фотографии галереи. Количество не ограничено.
CREATE TABLE IF NOT EXISTS `Image` (
  `id` CHAR(36) NOT NULL,
  `portfolio_id` CHAR(36) NOT NULL,
  `src` LONGTEXT NOT NULL,
  `name` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_image_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_image_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `Portfolio` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Аудио привязано к портфолио (одно на портфолио).
CREATE TABLE IF NOT EXISTS `audio` (
  `id` CHAR(36) NOT NULL,
  `portfolio_id` CHAR(36) NOT NULL,
  `src` LONGTEXT NOT NULL,
  `name` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_audio_portfolio` (`portfolio_id`),
  CONSTRAINT `fk_audio_portfolio`
    FOREIGN KEY (`portfolio_id`) REFERENCES `Portfolio` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Серверные сессии: id сессии хранится в cookie.
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` CHAR(36) NOT NULL,
  `user_id` CHAR(36) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_expires` (`expires_at`),
  CONSTRAINT `fk_sessions_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
