import { defineConfig } from 'vite';

export default defineConfig({
  // Relative paths keep the built site working when dist/index.html is
  // opened directly from disk or hosted in a subdirectory.
  base: './',
  server: {
    proxy: {
      '/api': 'http://localhost:3000',
    },
  },
});
